package com.springboot.security.oauth.common.service;

public interface BlogService {

}
