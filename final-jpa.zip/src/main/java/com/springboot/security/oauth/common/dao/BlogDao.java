package com.springboot.security.oauth.common.dao;

public interface BlogDao {

}
