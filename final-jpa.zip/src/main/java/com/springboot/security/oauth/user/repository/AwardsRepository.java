package com.springboot.security.oauth.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.security.oauth.user.entity.Awards;


@Repository
public interface AwardsRepository extends JpaRepository<Awards, Long> {
	List<Awards> findByUserId(Long userId);
}
