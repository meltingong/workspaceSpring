package com.springboot.security.oauth.corp.dao;

public interface CorpDao {

}
