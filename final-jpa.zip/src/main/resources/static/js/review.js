/**
 * review ajax -> test x
 */
 /*
 $.ajax({
    type: "POST",
    url: "/createReview",
    contentType: "application/json",
    data: JSON.stringify(reviewData),
    success: function(response) {
        // 서버로부터 성공 응답을 받은 경우
        var responseData = JSON.parse(response);
        if (responseData.success) {
            alert(responseData.message);
            // 페이지를 새로고침하거나 다른 작업을 수행
        } else {
            alert(responseData.message);
            // 오류 처리
        }
    },
    error: function(response) {
        // 서버로부터 오류 응답을 받은 경우
        alert("오류가 발생했습니다. 다시 시도해주세요.");
    }
});

	*/ 
	
