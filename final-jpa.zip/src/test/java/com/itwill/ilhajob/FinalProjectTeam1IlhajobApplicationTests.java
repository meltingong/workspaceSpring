package com.itwill.ilhajob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FinalProjectTeam1IlhajobApplicationTests {

	@Test
	void contextLoads() {
	}

}
