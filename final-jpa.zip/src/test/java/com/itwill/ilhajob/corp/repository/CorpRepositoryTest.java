package com.itwill.ilhajob.corp.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CorpRepositoryTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
